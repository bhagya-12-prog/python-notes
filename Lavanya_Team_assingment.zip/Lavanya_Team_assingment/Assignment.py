#!/usr/bin/env python
# coding: utf-8

# In[ ]:


Assignment#22


# In[26]:


x=4
y=3
def power(x,y):
     temp = 0
     if( y == 0):
         return 1
     temp = power(x, int(y / 2))
     if (y % 2 == 0):
            return temp * temp
     else:
        return x * temp * temp


# In[27]:


print(pow(x,y))


# In[ ]:




